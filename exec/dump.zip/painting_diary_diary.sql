-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: j7d203.p.ssafy.io    Database: painting_diary
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `diary`
--

DROP TABLE IF EXISTS `diary`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `diary` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email_name` varchar(45) NOT NULL,
  `drawing_id` int DEFAULT NULL,
  `title` varchar(50) NOT NULL,
  `content` varchar(500) NOT NULL,
  `weather` varchar(10) NOT NULL,
  `emotion` varchar(300) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `tag` varbinary(300) DEFAULT NULL,
  `is_deleted_from_child` tinyint NOT NULL,
  `emotion_all` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `drawing_id1_idx` (`drawing_id`),
  KEY `email_name3_idx` (`email_name`),
  CONSTRAINT `drawing_id1` FOREIGN KEY (`drawing_id`) REFERENCES `drawing` (`drawing_id`) ON DELETE SET NULL,
  CONSTRAINT `email_name3` FOREIGN KEY (`email_name`) REFERENCES `profile` (`email_name`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=324 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diary`
--

LOCK TABLES `diary` WRITE;
/*!40000 ALTER TABLE `diary` DISABLE KEYS */;
INSERT INTO `diary` VALUES (55,'cjdfid229@naver.com_보경이',99,'일기가 좋아 징짜','너무 재밌엉 제목은 점 안찍고 내용은 찍는 신기한 일기.','rain','','2022-10-05 00:00:00',NULL,0,NULL),(67,'cjdfid229@naver.com_보경이',112,'얄루','와우','rain','neutral ','2022-10-05 00:00:00',NULL,0,NULL),(101,'102132@naver.com_김싸피',71,'산책',' 오늘 친구와 같이 산책을 했다. 많은 이야기를 나눠서 너무 재미있는 시간이었다','sun','행복','2022-10-06 00:00:00',NULL,1,'anxious:15.77, happy:57.29, sad:8.19, angry:15.11, Surprised:3.64'),(102,'asd5687@naver.com_다은이',74,'오늘은 열심히 프로젝트를 해요 그런데 바빠','프로젝트 막바지가 다가온다. 화이팅!! 우린 할 수 있어','sun','불안','2022-10-06 00:00:00',NULL,0,'anxious:45.13, happy:10.66, sad:2.49, angry:40.06, Surprised:1.66'),(103,'pen2402@naver.com_정싸피',116,'안녕 방가워','무지개를 그려봤어. 정말 신난다.','sun','행복','2022-10-06 00:00:00',NULL,0,'anxious:10.11, happy:57.04, sad:6.65, angry:21.83, Surprised:4.37'),(105,'pen2402@naver.com_정싸피',116,'오늘은정말이지슬픈날이야','할일이 이렇게나 많다니. 너무 슬퍼.','sun','슬픔','2022-10-06 00:00:00',NULL,0,'anxious:25.81, happy:1.12, sad:50.51, angry:6.87, Surprised:15.69'),(106,'pen2402@naver.com_정싸피',116,'오늘은오늘은오늘은오늘은오늘은','걱정되는 하루야','sun','불안','2022-10-06 00:00:00',NULL,0,'anxious:36.48, happy:2.32, sad:24.29, angry:2.72, Surprised:34.19'),(107,'pen2402@naver.com_정싸피',116,'오늘하루는정말기쁘지아니할수없는그런','오늘은 하루종일 컴퓨터를 할 수 있었다. 기분이 좋았다. 그렇지만 힘들다!','sun','행복','2022-10-06 00:00:00',NULL,0,'anxious:25.17, happy:32.53, sad:27, angry:14.54, Surprised:0.76'),(109,'hmr2406@daum.net_박창성',118,'오늘은 수요일','신난다.','sun','행복','2022-10-06 00:00:00',NULL,1,'anxious:7.04, happy:55.41, sad:4.77, angry:26.83, Surprised:5.96'),(110,'hmr2406@daum.net_박창성',118,'오늘은 수요일','내일이 목요일이라서 기분이 좋아요.','cloud','행복','2022-10-06 00:00:00',NULL,0,'anxious:11.25, happy:58.24, sad:5.4, angry:18.27, Surprised:6.84'),(111,'102132@naver.com_김싸피',119,'산책','오늘 친구랑 산책을 했다.','sun','행복','2022-10-06 00:00:00',NULL,1,'anxious:18.01, happy:54.26, sad:9.51, angry:15.76, Surprised:2.45'),(112,'102132@naver.com_김싸피',120,'산책','오늘 친구랑 함께 산책을 했다.','sun','행복','2022-10-06 00:00:00',NULL,1,'anxious:18.03, happy:54.41, sad:8.72, angry:16.31, Surprised:2.53'),(113,'102132@naver.com_김싸피',121,'산책','오늘 친구와 함께 산책을 했다.','sun','행복','2022-10-06 00:00:00',NULL,0,'anxious:18.71, happy:54.4, sad:9.19, angry:15.17, Surprised:2.53'),(145,'cjdfid229@naver.com_보경이',123,'오늘이 짱이야','진짜 날씨 넣을지 감정 넣을지 고민이얌.','cloudy','놀람','2022-10-06 00:00:00',NULL,0,'anxious:5.21, happy:12.04, sad:6.01, angry:25.87, Surprised:50.87'),(169,'rhrhkd0014@gmail.com_김싸피',122,'산책','오늘 친구와 함께 산책을 했다.','sun','행복','2022-10-06 00:00:00',NULL,0,'슬픔:9.19, 분노:15.17, 행복:54.4, 불안:18.71, 놀람:2.53'),(170,'momssok1@gmail.com_test',NULL,'title','불안했다.','맑음','불안','2022-09-01 00:00:00',NULL,0,'슬픔:31.52, 분노:12.24, 행복:8, 불안:47.2, 놀람:1.03'),(171,'momssok1@gmail.com_test',NULL,'title','불안했다.','맑음','불안','2022-09-02 00:00:00',NULL,0,'슬픔:31.52, 분노:12.24, 행복:8, 불안:47.2, 놀람:1.03'),(172,'momssok1@gmail.com_test',NULL,'title','불안했다.','맑음','불안','2022-09-03 00:00:00',NULL,0,'슬픔:31.52, 분노:12.24, 행복:8, 불안:47.2, 놀람:1.03'),(173,'momssok1@gmail.com_test',NULL,'title','불안했다.','맑음','불안','2022-09-04 00:00:00',NULL,0,'슬픔:31.52, 분노:12.24, 행복:8, 불안:47.2, 놀람:1.03'),(174,'momssok1@gmail.com_test',NULL,'title','불안했다.','맑음','불안','2022-09-05 00:00:00',NULL,0,'슬픔:31.52, 분노:12.24, 행복:8, 불안:47.2, 놀람:1.03'),(175,'momssok1@gmail.com_test',NULL,'title','불안했다.','맑음','불안','2022-09-06 00:00:00',NULL,0,'슬픔:31.52, 분노:12.24, 행복:8, 불안:47.2, 놀람:1.03'),(176,'momssok1@gmail.com_test',NULL,'title','불안했다.','맑음','불안','2022-09-07 00:00:00',NULL,0,'슬픔:31.52, 분노:12.24, 행복:8, 불안:47.2, 놀람:1.03'),(177,'momssok1@gmail.com_test',NULL,'title','기뻤다.','맑음','행복','2022-09-08 00:00:00',NULL,0,'슬픔:9.05, 분노:20.65, 행복:56.99, 불안:9.41, 놀람:3.9'),(178,'momssok1@gmail.com_test',NULL,'title','기뻤다.','맑음','행복','2022-09-09 00:00:00',NULL,0,'슬픔:9.05, 분노:20.65, 행복:56.99, 불안:9.41, 놀람:3.9'),(179,'momssok1@gmail.com_test',NULL,'title','기뻤다.','맑음','행복','2022-09-10 00:00:00',NULL,0,'슬픔:9.05, 분노:20.65, 행복:56.99, 불안:9.41, 놀람:3.9'),(180,'momssok1@gmail.com_test',NULL,'title','기뻤다.','맑음','행복','2022-09-11 00:00:00',NULL,0,'슬픔:9.05, 분노:20.65, 행복:56.99, 불안:9.41, 놀람:3.9'),(181,'momssok1@gmail.com_test',NULL,'title','기뻤다.','맑음','행복','2022-09-12 00:00:00',NULL,0,'슬픔:9.05, 분노:20.65, 행복:56.99, 불안:9.41, 놀람:3.9'),(182,'momssok1@gmail.com_test',NULL,'title','기뻤다.','맑음','행복','2022-09-13 00:00:00',NULL,0,'슬픔:9.05, 분노:20.65, 행복:56.99, 불안:9.41, 놀람:3.9'),(183,'momssok1@gmail.com_test',NULL,'title','우울했다.','맑음','슬픔','2022-09-14 00:00:00',NULL,0,'슬픔:61.68, 분노:9.67, 행복:6.16, 불안:13.23, 놀람:9.25'),(184,'momssok1@gmail.com_test',NULL,'title','우울했다.','맑음','슬픔','2022-09-15 00:00:00',NULL,0,'슬픔:61.68, 분노:9.67, 행복:6.16, 불안:13.23, 놀람:9.25'),(185,'momssok1@gmail.com_test',NULL,'title','우울했다.','맑음','슬픔','2022-09-16 00:00:00',NULL,0,'슬픔:61.68, 분노:9.67, 행복:6.16, 불안:13.23, 놀람:9.25'),(193,'momssok1@gmail.com_test',NULL,'title','우울했다.','맑음','슬픔','2022-08-01 00:00:00',NULL,0,'슬픔:61.68, 분노:9.67, 행복:6.16, 불안:13.23, 놀람:9.25'),(194,'momssok1@gmail.com_test',NULL,'title','우울했다.','맑음','슬픔','2022-08-02 00:00:00',NULL,0,'슬픔:61.68, 분노:9.67, 행복:6.16, 불안:13.23, 놀람:9.25'),(195,'momssok1@gmail.com_test',NULL,'title','우울했다.','맑음','슬픔','2022-08-03 00:00:00',NULL,0,'슬픔:61.68, 분노:9.67, 행복:6.16, 불안:13.23, 놀람:9.25'),(196,'momssok1@gmail.com_test',NULL,'title','우울했다.','맑음','슬픔','2022-08-04 00:00:00',NULL,0,'슬픔:61.68, 분노:9.67, 행복:6.16, 불안:13.23, 놀람:9.25'),(198,'pen2402@naver.com_강싸피',132,'오늘은 정말 잊지 못할 하루였다','고양이를 봤기 때문이다. 너무 귀여워.','sun','행복','2022-10-06 00:00:00',NULL,0,'슬픔:2.36, 분노:16.27, 행복:51.41, 불안:5, 놀람:24.96'),(199,'momssok1@gmail.com_name2',103,'123','123','sun','분노','2022-10-06 00:00:00',NULL,0,'슬픔:23.32, 분노:35.5, 행복:15.98, 불안:3.59, 놀람:21.62'),(271,'102132@naver.com_김싸피',139,'비가 오네','오늘은 비가 엄청 많이 와서 기분이 우울하다.','rain','슬픔','2022-10-07 00:00:00',NULL,0,'슬픔:53.16, 분노:2.06, 행복:6.75, 불안:22.54, 놀람:15.48'),(272,'cjdfid229@naver.com_보경이',143,'지난달에 쓰지만 이번달에 쓰는 일기','이건 글씨가 아니가 우울해. 정말 글씨는쉽지가 않네요.','sun','슬픔','2022-09-27 00:00:00',NULL,0,'슬픔:49.3, 분노:5.24, 행복:2.66, 불안:6, 놀람:36.8'),(310,'ckstjr76@naver.com_보경이',145,'날씨가 좋아요','오늘은 날씨가 쨍쨍해서 기분이 날아갈거처럼 좋아요 항상 날씨가 좋으면 좋겠다.','sun','행복','2022-10-07 00:00:00',NULL,0,'슬픔:6.42, 분노:25.02, 행복:55.62, 불안:9.13, 놀람:3.81'),(312,'pen2402@naver.com_강싸피',152,'너무 재밌는 하루','오늘 너무 행복하고 재밌는 하루다','sun','행복','2022-10-07 00:00:00',NULL,0,'슬픔:5.46, 분노:23.79, 행복:56.11, 불안:8.54, 놀람:6.09'),(323,'pen2402@naver.com_정싸피',160,'강아지 귀여워','오늘 길 가다 강아지를 봤는데 너무 귀여웠다!!.','sun','행복','2022-10-07 00:00:00',NULL,1,'슬픔:4.93, 분노:20.32, 행복:57.89, 불안:11.13, 놀람:5.73');
/*!40000 ALTER TABLE `diary` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-07 11:45:55
