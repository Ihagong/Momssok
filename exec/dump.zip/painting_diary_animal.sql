-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: j7d203.p.ssafy.io    Database: painting_diary
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `animal`
--

DROP TABLE IF EXISTS `animal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `animal` (
  `id` int NOT NULL,
  `name` varchar(45) NOT NULL,
  `name_ko` varchar(45) NOT NULL,
  `description` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `animal`
--

LOCK TABLES `animal` WRITE;
/*!40000 ALTER TABLE `animal` DISABLE KEYS */;
INSERT INTO `animal` VALUES (1,'dog','개','오랫동안 사람과 함께 살아 온 동물!<br />어린 개를 ‘강아지’라고 해요.<br />냄새를 잘 맡고 충성심이 강해서 우리에게<br />도움을 많이 준답니다. 하지만 조심하세요!<br />늑대와 조상이 같아서 이빨이 뾰족해요.'),(2,'rabbit','토끼','깜짝이야! 똥을 주워먹어도 놀라지 마세요.<br />풍부한 영양분을 다시 소화시키는 거랍니다.<br />큰 귀로 작은 소리를 듣고 체온을 조절해요.<br />튼튼한 뒷다리로 깡총깡총 뛸 수 있답니다.<br />사실.. 당근보다 건초를 더 좋아한대요!'),(3,'elephant','코끼리','땅에 사는 동물 가운데 가장 크고 무거워요.<br />긴 코는 근육질이라 나무도 들 수 있지요.<br />코 옆에 긴 송곳니는 ‘상아’라고 해요.<br />귀는 밝지만 눈은 어두워서 음파로 대화해요.<br />풀을 많이 먹어서 방귀를 많이 뀐답니다!'),(4,'cat','고양이','사뿐사뿐 높은 곳이나 좁은 곳도 잘 걷지요.<br />날카로운 이빨, 넣고 꺼낼 수 있는 발톱으로<br />쥐나 작은 새를 사냥하기도 한답니다!<br />잠이 많아서 낮보다 밤에 많이 활동해요.<br />몸이 유연하고 밤 눈이 밝답니다.');
/*!40000 ALTER TABLE `animal` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-07 11:45:55
