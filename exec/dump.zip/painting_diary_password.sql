-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: j7d203.p.ssafy.io    Database: painting_diary
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `password`
--

DROP TABLE IF EXISTS `password`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password` (
  `email` varchar(30) NOT NULL,
  `password` varchar(80) NOT NULL,
  KEY `user_email1` (`email`),
  CONSTRAINT `user_email1` FOREIGN KEY (`email`) REFERENCES `user` (`email`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password`
--

LOCK TABLES `password` WRITE;
/*!40000 ALTER TABLE `password` DISABLE KEYS */;
INSERT INTO `password` VALUES ('momssok1@gmail.com','$2a$10$DC877LhyRCAlKNiIMuEGaepirZRsE9uIQw5J8K7yHibVzzdYLWj0y'),('cjdfid229@naver.com','$2a$10$e25sbF1ECmoTYAD9Qx2gleF/aCne8rUT6LYWylhGdggjJOxrpbVxe'),('enddl3054@naver.com','$2a$10$TBz0C4o7gcx4PWtlQweRXOfvGL5bYucueYXMq2hJJ7w6APi.egv2G'),('hmr2406@daum.net','$2a$10$DNPW3IHDIRVwHBcLwb5N0eAbJD64zd3V3RyWdkonKrl9lzQduMYdq'),('gkagmlwn94@naver.com','$2a$10$jZZoL43VNtMYGDHNoF1uq.Ik1Jkwu.gLuLPcWQ3x6zfgCQQydEVIy'),('102132@naver.com','$2a$10$87EdEf3e02E23suKWUzQMuJ2WX7Tz/QBoV3fVFOciJpAqw4BZJ7kS'),('pen2402@naver.com','$2a$10$kpXqT78zm3PY8lY8.i1NqugZcdYQA48.42tEHvSjfMFNOlfJtxyWW'),('asd5687@naver.com','$2a$10$DBmxsh6eeU4TlCt5KH1BzOEW.jZ7i1TY7vSbUcl8BH9AmOuhICFfG'),('josin0324@naver.com','$2a$10$J5vch2Xb.zmizOFZvlgaFOxdD2BZc4lcWK2EGoIAf5yQHw1oVH5jW'),('pink5910@naver.com','$2a$10$vJ/OlVImt/nm7OTUCYlunu/i21lO9N8jjCid9FiAY17BLqJD3iN4W'),('tgd_5753@naver.com','$2a$10$QJbNnSuAswESefZzOGSiQucChM9HTS3Szu4PCaql.kQmB1p8A0aF6'),('rhrhkd0014@gmail.com','$2a$10$SI3eYcF5iWweMKMaXWQQU.ZvIUtGYNFH7ol6kaIVcSF0ehz8Qorp2'),('ckstjr76@naver.com','$2a$10$XEjJBOUs3KRFFOKJfwSGGOougPwroh83hh4yN/5MLC3YFAKKgPLzm');
/*!40000 ALTER TABLE `password` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-07 11:46:00
