-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: j7d203.p.ssafy.io    Database: painting_diary
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `promise`
--

DROP TABLE IF EXISTS `promise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `promise` (
  `promise_id` int NOT NULL AUTO_INCREMENT,
  `email_name` varchar(45) DEFAULT NULL,
  `promise_list` blob,
  `promise_completed` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`promise_id`),
  KEY `email_name_idx` (`email_name`),
  CONSTRAINT `email_name` FOREIGN KEY (`email_name`) REFERENCES `profile` (`email_name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `promise`
--

LOCK TABLES `promise` WRITE;
/*!40000 ALTER TABLE `promise` DISABLE KEYS */;
INSERT INTO `promise` VALUES (148,'momssok1@gmail.com_test',_binary '�\�\0sr\0java.util.ArrayListx�\��\�a�\0I\0sizexp\0\0\0w\0\0\0sr\0,com.ihagong.momssok.model.dto.PromiseItemDtoH*fe�\0I\0doneI\0idL\0giftt\0Ljava/lang/String;L\0todoListt\0Ljava/util/List;xp\0\0\0\0\0\0\0t\0선물23sq\0~\0\0\0\0\0w\0\0\0sr\01com.ihagong.momssok.model.dto.PromiseInnerItemDto\�\�:�U�V\�\0I\0doneI\0idL\0todoq\0~\0xp\0\0\0\0\0\0\0t\0레이아웃 잡기2sq\0~\0\0\0\0\0\0\0\0t\0레이아웃 잡기3xsq\0~\0\0\0\0\0\0\0\0t\0선물1sq\0~\0\0\0\0\0w\0\0\0sq\0~\0\0\0\0\0\0\0\0t\0레이아웃 잡기1sq\0~\0\0\0\0\0\0\0\0t\0레이아웃 잡기1xsq\0~\0\0\0\0\0\0\0\0t\0선물22sq\0~\0\0\0\0\0w\0\0\0sq\0~\0\0\0\0\0\0\0\0t\0레이아웃 잡기3xx',0),(150,'hmr2406@daum.net_박창성',_binary '�\�\0sr\0java.util.ArrayListx�\��\�a�\0I\0sizexp\0\0\0w\0\0\0sr\0,com.ihagong.momssok.model.dto.PromiseItemDtoH*fe�\0I\0doneI\0idL\0giftt\0Ljava/lang/String;L\0todoListt\0Ljava/util/List;xp\0\0\0\0\0\0t\0선물sq\0~\0\0\0\0\0w\0\0\0sr\01com.ihagong.momssok.model.dto.PromiseInnerItemDto\�\�:�U�V\�\0I\0doneI\0idL\0todoq\0~\0xp\0\0\0\0\0\0\0t\0\0xsq\0~\0\0\0\0\0\0\0\0t\0맥북sq\0~\0\0\0\0\0w\0\0\0sq\0~\0\0\0\0\0\0\0\0t\0받아쓰기 100점xx',0),(151,'cjdfid229@naver.com_보경이',_binary '�\�\0sr\0java.util.ArrayListx�\��\�a�\0I\0sizexp\0\0\0w\0\0\0sr\0,com.ihagong.momssok.model.dto.PromiseItemDtoH*fe�\0I\0doneI\0idL\0giftt\0Ljava/lang/String;L\0todoListt\0Ljava/util/List;xp\0\0\0\0\0\0t\0최고sq\0~\0\0\0\0\0w\0\0\0sr\01com.ihagong.momssok.model.dto.PromiseInnerItemDto\�\�:�U�V\�\0I\0doneI\0idL\0todoq\0~\0xp\0\0\0\0\0\0t\0ㅇㅇㅇㅇㅇㅇㅇsq\0~\0\0\0\0\0\0\0t\0	ㅇㅇㄴxsq\0~\0\0\0\0\0\0\0t\0\0sq\0~\0\0\0\0\0w\0\0\0sq\0~\0\0\0\0\0\0\0t\0오늘은 짱이야!xsq\0~\0\0\0\0\0\0\0t\0\0sq\0~\0\0\0\0\0w\0\0\0sq\0~\0\0\0\0\0\0\0\0t\0와우sq\0~\0\0\0\0\0\0\0\0t\0&코끼리는 코가 움직이잖아요sq\0~\0\0\0\0\0\0\0\0t\0\r아 정말요xsq\0~\0\0\0\0\0\0\0t\0\0sq\0~\0\0\0\0\0w\0\0\0sq\0~\0\0\0\0\0\0\0\0t\0	ㅁㅁㅁxx',0),(152,'rhrhkd0014@gmail.com_김싸피',_binary '�\�\0sr\0java.util.ArrayListx�\��\�a�\0I\0sizexp\0\0\0w\0\0\0sr\0,com.ihagong.momssok.model.dto.PromiseItemDtoH*fe�\0I\0doneI\0idL\0giftt\0Ljava/lang/String;L\0todoListt\0Ljava/util/List;xp\0\0\0\0\0\0t\0용돈sq\0~\0\0\0\0\0w\0\0\0sr\01com.ihagong.momssok.model.dto.PromiseInnerItemDto\�\�:�U�V\�\0I\0doneI\0idL\0todoq\0~\0xp\0\0\0\0\0\0t\0숙제하기xsq\0~\0\0\0\0\0\0\0\0t\0치킨sq\0~\0\0\0\0\0w\0\0\0sq\0~\0\0\0\0\0\0\0t\0\r양치 하기sq\0~\0\0\0\0\0\0\0t\0\r양치 하기sq\0~\0\0\0\0\0\0\0t\0\r양치 하기xsq\0~\0\0\0\0\0\0\0\0t\0치킨sq\0~\0\0\0\0\0w\0\0\0sq\0~\0\0\0\0\0\0\0\0t\0	밥먹기sq\0~\0\0\0\0\0\0\0\0t\0	밥먹기sq\0~\0\0\0\0\0\0\0\0t\0	밥먹기xsq\0~\0\0\0\0\0\0\0\0t\0\0sq\0~\0\0\0\0\0w\0\0\0sq\0~\0\0\0\0\0\0\0t\0Csq\0~\0\0\0\0\0\0\0t\0Cxsq\0~\0\0\0\0\0\0\0t\0치킨sq\0~\0\0\0\0\0w\0\0\0sq\0~\0\0\0\0\0\0\0t\0이sq\0~\0\0\0\0\0\0\0t\0아이유ㅊㅊㅊㅊxx',0),(153,'asd5687@naver.com_다은이',_binary '�\�\0sr\0java.util.ArrayListx�\��\�a�\0I\0sizexp\0\0\0w\0\0\0sr\0,com.ihagong.momssok.model.dto.PromiseItemDtoH*fe�\0I\0doneI\0idL\0giftt\0Ljava/lang/String;L\0todoListt\0Ljava/util/List;xp\0\0\0\0\0\0t\0선물sq\0~\0\0\0\0\0w\0\0\0sr\01com.ihagong.momssok.model.dto.PromiseInnerItemDto\�\�:�U�V\�\0I\0doneI\0idL\0todoq\0~\0xp\0\0\0\0\0\0\0t\0aaxsq\0~\0\0\0\0\0\0\0t\0\0sq\0~\0\0\0\0\0w\0\0\0sq\0~\0\0\0\0\0\0\0\0t\0.xsq\0~\0\0\0\0\0\0\0t\0\0sq\0~\0\0\0\0\0w\0\0\0sq\0~\0\0\0\0\0\0\0\0q\0~\0xsq\0~\0\0\0\0\0\0\0t\0\0sq\0~\0\0\0\0\0w\0\0\0sq\0~\0\0\0\0\0\0\0\0t\0dkssudxsq\0~\0\0\0\0\0\0\0t\0\0sq\0~\0\0\0\0\0w\0\0\0sq\0~\0\0\0\0\0\0\0\0t\0ggxx',0),(154,'102132@naver.com_김싸피',_binary '�\�\0sr\0java.util.ArrayListx�\��\�a�\0I\0sizexp\0\0\0w\0\0\0sr\0,com.ihagong.momssok.model.dto.PromiseItemDtoH*fe�\0I\0doneI\0idL\0giftt\0Ljava/lang/String;L\0todoListt\0Ljava/util/List;xp\0\0\0\0\0\0t\0\0sq\0~\0\0\0\0\0w\0\0\0sr\01com.ihagong.momssok.model.dto.PromiseInnerItemDto\�\�:�U�V\�\0I\0doneI\0idL\0todoq\0~\0xp\0\0\0\0\0\0t\0양치하기xsq\0~\0\0\0\0\0\0\0t\0\0sq\0~\0\0\0\0\0w\0\0\0sq\0~\0\0\0\0\0\0\0\0t\0밥 꼭꼭 씹어먹기xsq\0~\0\0\0\0\0\0\0t\0\0sq\0~\0\0\0\0\0w\0\0\0sq\0~\0\0\0\0\0\0\0t\0칭찬 일기쓰기xsq\0~\0\0\0\0\0\0\0t\0\0sq\0~\0\0\0\0\0w\0\0\0sq\0~\0\0\0\0\0\0\0t\0요sq\0~\0\0\0\0\0\0\0t\0대sq\0~\0\0\0\0\0\0\0t\0ㄹxsq\0~\0\0\0\0\0\0\0t\0\0sq\0~\0\0\0\0\0w\0\0\0sq\0~\0\0\0\0\0\0\0t\0	ㄹㄹㄹxsq\0~\0\0\0\0\0\0\0t\0\0sq\0~\0\0\0\0\0w\0\0\0sq\0~\0\0\0\0\0\0\0t\0\r일기 쓰기xx',0),(155,'pen2402@naver.com_정싸피',_binary '�\�\0sr\0java.util.ArrayListx�\��\�a�\0I\0sizexp\0\0\0w\0\0\0sr\0,com.ihagong.momssok.model.dto.PromiseItemDtoH*fe�\0I\0doneI\0idL\0giftt\0Ljava/lang/String;L\0todoListt\0Ljava/util/List;xp\0\0\0\0\0\0t\0선물sq\0~\0\0\0\0\0w\0\0\0sr\01com.ihagong.momssok.model.dto.PromiseInnerItemDto\�\�:�U�V\�\0I\0doneI\0idL\0todoq\0~\0xp\0\0\0\0\0\0\0t\0숙제하기xsq\0~\0\0\0\0\0\0\0t\0\0sq\0~\0\0\0\0\0w\0\0\0sq\0~\0\0\0\0\0\0\0\0t\0청소하기xsq\0~\0\0\0\0\0\0\0t\0\0sq\0~\0\0\0\0\0w\0\0\0sq\0~\0\0\0\0\0\0\0t\0책상 정리하기sq\0~\0\0\0\0\0\0\0\0t\0\r일기 쓰기xsq\0~\0\0\0\0\0\0\0\0t\0\0sq\0~\0\0\0\0\0w\0\0\0sq\0~\0\0\0\0\0\0\0\0t\0설거지하기xx',0),(156,'pen2402@naver.com_강싸피',_binary '�\�\0sr\0java.util.ArrayListx�\��\�a�\0I\0sizexp\0\0\0w\0\0\0sr\0,com.ihagong.momssok.model.dto.PromiseItemDtoH*fe�\0I\0doneI\0idL\0giftt\0Ljava/lang/String;L\0todoListt\0Ljava/util/List;xp\0\0\0\0\0\0\0t\0선물sq\0~\0\0\0\0\0w\0\0\0sr\01com.ihagong.momssok.model.dto.PromiseInnerItemDto\�\�:�U�V\�\0I\0doneI\0idL\0todoq\0~\0xp\0\0\0\0\0\0t\0양치 잘하기sq\0~\0\0\0\0\0\0\0\0t\0일기쓰기xx',0);
/*!40000 ALTER TABLE `promise` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-07 11:45:58
