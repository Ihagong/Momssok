-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: j7d203.p.ssafy.io    Database: painting_diary
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `letter`
--

DROP TABLE IF EXISTS `letter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `letter` (
  `letter_id` int NOT NULL AUTO_INCREMENT,
  `send_from` varchar(45) NOT NULL,
  `send_to` varchar(45) NOT NULL,
  `title` varchar(50) NOT NULL,
  `content` varchar(500) NOT NULL,
  `video_path` varchar(200) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `read_check` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`letter_id`),
  KEY `email_name1_idx` (`send_from`),
  KEY `email_name2_idx` (`send_to`),
  CONSTRAINT `email_name1` FOREIGN KEY (`send_from`) REFERENCES `profile` (`email_name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `email_name2` FOREIGN KEY (`send_to`) REFERENCES `profile` (`email_name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `letter`
--

LOCK TABLES `letter` WRITE;
/*!40000 ALTER TABLE `letter` DISABLE KEYS */;
INSERT INTO `letter` VALUES (40,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/var/lib/docker/volumes/volume1/_data/e33ecde7-6ff6-4298-bd6c-c6840e2ca04c_동물친구들.mp4','2022-09-29 02:33:08',NULL),(43,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/var/lib/docker/volumes/volume1/_data/785c82d0-e3a1-4904-8023-708913cd992b_동물친구들.mp4','2022-09-29 16:05:54',NULL),(44,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/var/lib/docker/volumes/volume1/_data/84a80c1e-404a-4f71-a892-18d7eb3794eb_동물친구들.mp4','2022-09-29 16:07:06',NULL),(45,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/var/lib/docker/volumes/volume1/_data/c778b25d-4694-43f5-997d-bd452025e109_동물친구들.mp4','2022-09-29 16:09:43',NULL),(47,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test','test2','','2022-09-28 22:12:32',NULL),(48,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/var/lib/docker/volumes/volume1/_data/7e507bed-b8f2-4daa-b626-df782268533b_동물친구들.mp4','2022-09-29 16:12:54',NULL),(49,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/var/lib/docker/volumes/volume1/_data/5d0d461f-5fe9-4852-899a-ae3af5c028e8_동물친구들.mp4','2022-09-28 22:19:13',NULL),(51,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/var/lib/docker/volumes/volume1/_data/ca4f1b63-3ba0-4e0d-92ec-c7b75f29fd97_동물친구들.mp4','2022-09-28 22:23:20',NULL),(52,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/var/lib/docker/volumes/volume1/_data/b9d797fd-e16a-4532-8989-d2f50a43de0f_동물친구들.mp4','2022-09-29 17:10:29',NULL),(53,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/var/lib/docker/volumes/volume1/_data/81f74986-7d12-4b49-8ece-a21599283ec1_동물친구들.mp4','2022-09-29 17:17:30',NULL),(54,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/var/lib/docker/volumes/volume1/_data/90b2f02e-064b-4a22-a381-44de6bffa52a_동물친구들.mp4','2022-09-29 22:11:54',NULL),(55,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/var/lib/docker/volumes/volume1/_data/55138bb3-5271-4fc4-8578-613ac61f7c1a_동물친구들.mp4','2022-09-29 22:24:48',NULL),(56,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/var/lib/docker/volumes/volume1/_data/1a758110-f8f4-406d-9f1c-94ed6a21e22d_동물친구들.mp4','2022-09-29 22:44:19',NULL),(57,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/var/lib/docker/volumes/volume1/_data/4dbd8034-f924-4c3d-aa3c-f5c9ddc4bfec_동물친구들.mp4','2022-09-29 22:46:08',NULL),(58,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/var/lib/docker/volumes/volume1/_data/bed61732-b217-41c2-a86f-d9a81766d991_동물친구들.mp4','2022-09-29 22:52:42',NULL),(59,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/var/lib/docker/volumes/volume1/_data/050f0c7c-b64b-4625-addc-00db508a3ba5_동물친구들.mp4','2022-09-29 14:07:23',NULL),(60,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/var/lib/docker/volumes/volume1/_data/f3582bc8-7b66-4bed-9088-d18463c0585d_동물친구들.mp4','2022-09-29 14:08:24',NULL),(61,'cjdfid229@naver.com_보경이','cjdfid229@naver.com_찬석맘','엄마에게','엄마최고',NULL,'2022-09-30 02:20:23',NULL),(66,'cjdfid229@naver.com_보경이','cjdfid229@naver.com_찬석맘','안녕','찬석맘',NULL,'2022-09-30 02:59:08',1),(68,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/var/lib/docker/volumes/volume1/_data/057f736b-5a48-4f6a-a55a-d39776069250_동물친구들.mp4','2022-10-02 20:33:46',NULL),(69,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/var/lib/docker/volumes/volume1/_data/79a57673-d608-4645-84e4-5fad4132ef7d_동물친구들.mp4','2022-10-02 20:41:17',NULL),(70,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/files1ea1d888d-e9ff-4db6-bf66-409b0f312b7f_동물친구들.mp4','2022-10-02 20:49:26',NULL),(71,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/files19a94a8d6-0e93-411b-9ea2-7e7d4c1d09de_동물친구들.mp4','2022-10-02 21:08:17',NULL),(72,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/files15381f3a8-c46b-4170-96b8-e19371243642_동물친구들.mp4','2022-10-02 21:10:20',NULL),(73,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/files19f7a0d4f-a2eb-4907-94b5-5c6cc6dd947e_동물친구들.mp4','2022-10-02 21:16:46',NULL),(74,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/files1d9ad4d01-2b6d-42a9-b03c-4cce10bb25a5_동물친구들.mp4','2022-10-02 21:37:54',NULL),(75,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/files1/bacc5b6a-645f-4cfb-9a48-eb245f5dee64_동물친구들.mp4','2022-10-02 21:53:25',NULL),(76,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/files1/ca25a0e6-6ca6-4bbc-bc59-ae0960c41614_동물친구들.mp4','2022-10-02 21:53:26',NULL),(77,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/files1/7b2d55f6-12e0-4a1c-816d-57fe481e2ae8_동물친구들.mp4','2022-10-02 21:53:33',NULL),(80,'momssok1@gmail.com_test','momssok1@gmail.com_name2','test1','test8','/files1/ad13c929-3d73-4427-b6f8-dd6b1c8cfa33_동물친구들.mp4','2022-10-05 13:47:51',1),(82,'asd5687@naver.com_다은이','asd5687@naver.com_참돌이','참돌아 안녕','반갑다 나는 다은이야',NULL,'2022-10-05 17:24:37',1);
/*!40000 ALTER TABLE `letter` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-07 11:45:59
