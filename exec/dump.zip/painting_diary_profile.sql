-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: j7d203.p.ssafy.io    Database: painting_diary
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `profile`
--

DROP TABLE IF EXISTS `profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `profile` (
  `email_name` varchar(45) NOT NULL,
  `email` varchar(30) NOT NULL,
  `name` varchar(10) NOT NULL,
  `birthday` date DEFAULT NULL,
  `image_num` int DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime DEFAULT NULL,
  `profile_password` varchar(4) DEFAULT NULL,
  `is_parent` tinyint DEFAULT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`email_name`),
  KEY `user_email3` (`email`),
  CONSTRAINT `user_email3` FOREIGN KEY (`email`) REFERENCES `user` (`email`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `profile`
--

LOCK TABLES `profile` WRITE;
/*!40000 ALTER TABLE `profile` DISABLE KEYS */;
INSERT INTO `profile` VALUES ('102132@naver.com_고광','102132@naver.com','고광',NULL,NULL,'2022-10-04 02:06:02',NULL,NULL,1,NULL),('102132@naver.com_김싸피','102132@naver.com','김싸피','2016-10-13',0,'2022-10-04 02:24:48',NULL,NULL,0,NULL),('asd5687@naver.com_다은맘','asd5687@naver.com','다은맘',NULL,NULL,'2022-10-04 12:24:30',NULL,NULL,1,NULL),('asd5687@naver.com_다은이','asd5687@naver.com','다은이','1999-01-07',1,'2022-10-04 12:25:14',NULL,NULL,0,NULL),('asd5687@naver.com_참돌이','asd5687@naver.com','참돌이','2018-01-01',5,'2022-10-04 13:36:18',NULL,NULL,0,NULL),('cjdfid229@naver.com_보경이','cjdfid229@naver.com','보경이','2020-08-03',4,'2022-09-30 02:19:53','2022-10-04 02:51:26',NULL,0,NULL),('cjdfid229@naver.com_성령이','cjdfid229@naver.com','성령이','2018-08-04',2,'2022-09-30 02:59:24','2022-10-04 02:50:31',NULL,0,NULL),('cjdfid229@naver.com_찬석맘','cjdfid229@naver.com','찬석맘',NULL,NULL,'2022-09-28 16:45:28',NULL,NULL,1,NULL),('ckstjr76@naver.com_보경맘','ckstjr76@naver.com','보경맘',NULL,NULL,'2022-10-07 00:49:23',NULL,NULL,1,NULL),('ckstjr76@naver.com_보경이','ckstjr76@naver.com','보경이','2017-03-15',4,'2022-10-07 00:50:03','2022-10-07 00:50:16',NULL,0,NULL),('ckstjr76@naver.com_찬석이','ckstjr76@naver.com','찬석이','2019-08-26',5,'2022-10-07 00:50:48',NULL,NULL,0,NULL),('enddl3054@naver.com_김맹뭉','enddl3054@naver.com','김맹뭉',NULL,NULL,'2022-09-29 15:18:46',NULL,NULL,1,NULL),('gkagmlwn94@naver.com_구경하러왔습니다','gkagmlwn94@naver.com','구경하러왔습니다',NULL,NULL,'2022-09-30 08:59:49',NULL,NULL,1,NULL),('gkagmlwn94@naver.com_어린이','gkagmlwn94@naver.com','어린이','2010-03-02',5,'2022-10-04 13:38:13',NULL,NULL,0,NULL),('hmr2406@daum.net_김성령','hmr2406@daum.net','김성령',NULL,NULL,'2022-09-29 15:36:02',NULL,NULL,1,NULL),('hmr2406@daum.net_박창성','hmr2406@daum.net','박창성','2016-05-05',5,'2022-09-29 16:30:22','2022-10-01 08:29:17',NULL,0,NULL),('josin0324@naver.com_김다','josin0324@naver.com','김다','1999-01-07',4,'2022-10-05 04:46:27',NULL,NULL,0,NULL),('josin0324@naver.com_다은김','josin0324@naver.com','다은김',NULL,NULL,'2022-10-04 13:30:39',NULL,NULL,1,NULL),('momssok1@gmail.com_name2','momssok1@gmail.com','name2','2000-01-01',3,'2022-09-28 15:57:19','2022-09-28 22:24:12','1224',0,NULL),('momssok1@gmail.com_test','momssok1@gmail.com','test',NULL,NULL,'2022-09-28 15:55:42',NULL,NULL,1,'2022-10-05 04:50:24'),('pen2402@naver.com_강싸피','pen2402@naver.com','강싸피','2017-09-09',4,'2022-10-06 13:33:58',NULL,NULL,0,NULL),('pen2402@naver.com_김싸피','pen2402@naver.com','김싸피',NULL,NULL,'2022-10-04 06:21:29',NULL,NULL,1,NULL),('pen2402@naver.com_정싸피','pen2402@naver.com','정싸피','2019-03-03',1,'2022-10-05 17:35:27',NULL,NULL,0,NULL),('pink5910@naver.com_박춘석','pink5910@naver.com','박춘석','1907-01-01',5,'2022-10-04 14:25:29',NULL,NULL,0,NULL),('pink5910@naver.com_박춘식','pink5910@naver.com','박춘식',NULL,NULL,'2022-10-04 14:24:54',NULL,NULL,1,NULL),('rhrhkd0014@gmail.com_김싸피','rhrhkd0014@gmail.com','김싸피','2017-05-01',0,'2022-10-06 00:38:53',NULL,NULL,0,NULL),('rhrhkd0014@gmail.com_싸피부모님','rhrhkd0014@gmail.com','싸피부모님',NULL,NULL,'2022-10-06 00:38:32',NULL,NULL,1,NULL),('tgd_5753@naver.com_aa','tgd_5753@naver.com','aa',NULL,NULL,'2022-10-04 18:00:19',NULL,NULL,1,NULL),('tgd_5753@naver.com_ㅋㅋ','tgd_5753@naver.com','ㅋㅋ','1990-01-01',3,'2022-10-04 18:00:44',NULL,NULL,0,NULL);
/*!40000 ALTER TABLE `profile` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-10-07 11:46:00
